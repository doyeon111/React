import React from 'react';
import { Button, Navbar, Nav, Container, NavDropdown } from 'react-bootstrap';
import './App.css';
import ReactDOM from 'react-dom';
import Order from './pages/Order';
import { Route, Link } from 'react-router-dom';

function App() {
  return (
    <div className="Container">
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="/">Caffe</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">

              <Nav.Link><Link to= "/">Home</Link></Nav.Link>
              <Nav.Link><Link to ="/order">Order</Link></Nav.Link>

                <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Route path="/" exact={true}>
      <div class="jumbotron">
        <h1 class="display-5 fw-bold">Caffe & Tea</h1>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4" />
        <p>온라인으로 주문하고 편하게 커피를 받아 보세요!</p>
        <a class="btn btn-primary btn-lg" href="/order" role="button">yj반 20213806 김도연</a>
      </div>
      </Route>
      <Route path="/order" component={Order}>
      </Route>
        
      </div>
    );
}

export default App;
